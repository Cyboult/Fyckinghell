const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

interface ScamAlert {
  id: string;
  title: string;
  description: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  type: string;
  location: string;
  reportedCases: number;
  avgLoss: string;
  date: string;
  trend: 'increasing' | 'decreasing' | 'stable';
}

// Sample scam alerts data
const scamAlerts: ScamAlert[] = [
  {
    id: '1',
    title: 'Fake IRS Tax Refund Emails',
    description: 'Scammers are sending fake IRS emails claiming you have a tax refund. The emails contain malicious links that steal personal information.',
    severity: 'high',
    type: 'Phishing',
    location: 'Nationwide',
    reportedCases: 1247,
    avgLoss: '$2,340',
    date: '2024-01-15',
    trend: 'increasing'
  },
  {
    id: '2',
    title: 'Romance Scam on Dating Apps',
    description: 'Fraudsters are creating fake profiles on popular dating apps to build relationships and then request money for emergencies.',
    severity: 'critical',
    type: 'Romance Scam',
    location: 'Global',
    reportedCases: 892,
    avgLoss: '$8,750',
    date: '2024-01-14',
    trend: 'stable'
  },
  {
    id: '3',
    title: 'Tech Support Phone Scams',
    description: 'Callers claiming to be from Microsoft or Apple are calling users about computer problems and requesting remote access.',
    severity: 'medium',
    type: 'Phone Scam',
    location: 'North America',
    reportedCases: 634,
    avgLoss: '$450',
    date: '2024-01-13',
    trend: 'decreasing'
  }
];

Deno.serve(async (req: Request) => {
  try {
    if (req.method === "OPTIONS") {
      return new Response(null, {
        status: 200,
        headers: corsHeaders,
      });
    }

    if (req.method === "GET") {
      const url = new URL(req.url);
      const severity = url.searchParams.get('severity');
      
      let alerts = scamAlerts;
      if (severity && severity !== 'all') {
        alerts = scamAlerts.filter(alert => alert.severity === severity);
      }

      return new Response(
        JSON.stringify({
          success: true,
          alerts: alerts.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()),
        }),
        {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    return new Response(
      JSON.stringify({ error: "Method not allowed" }),
      {
        status: 405,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});