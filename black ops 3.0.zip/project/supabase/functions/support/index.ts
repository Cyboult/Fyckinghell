const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

interface SupportTicket {
  id?: string;
  userId: string;
  category: string;
  message: string;
  status?: string;
  createdAt?: string;
}

interface ContactMessage {
  id?: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  status?: string;
  createdAt?: string;
}

// In-memory storage for demo
const supportTickets: SupportTicket[] = [];
const contactMessages: ContactMessage[] = [];

Deno.serve(async (req: Request) => {
  try {
    if (req.method === "OPTIONS") {
      return new Response(null, {
        status: 200,
        headers: corsHeaders,
      });
    }

    const url = new URL(req.url);
    const path = url.pathname;

    if (req.method === "POST" && path.includes("/support")) {
      const data = await req.json();

      if (data.category) {
        // Support ticket
        const ticket: SupportTicket = {
          id: crypto.randomUUID(),
          ...data,
          status: 'open',
          createdAt: new Date().toISOString(),
        };
        supportTickets.push(ticket);

        return new Response(
          JSON.stringify({
            success: true,
            ticket,
            message: "Support ticket created successfully",
          }),
          {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          }
        );
      } else {
        // Contact message
        const message: ContactMessage = {
          id: crypto.randomUUID(),
          ...data,
          status: 'new',
          createdAt: new Date().toISOString(),
        };
        contactMessages.push(message);

        return new Response(
          JSON.stringify({
            success: true,
            message: "Contact message sent successfully",
          }),
          {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          }
        );
      }
    }

    if (req.method === "GET" && path.includes("/support")) {
      const userId = url.searchParams.get('userId');
      
      let tickets = supportTickets;
      if (userId) {
        tickets = supportTickets.filter(ticket => ticket.userId === userId);
      }

      return new Response(
        JSON.stringify({
          success: true,
          tickets: tickets.sort((a, b) => 
            new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
          ),
        }),
        {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    return new Response(
      JSON.stringify({ error: "Not found" }),
      {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});