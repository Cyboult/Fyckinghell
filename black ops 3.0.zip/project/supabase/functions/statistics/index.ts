const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

interface Statistics {
  totalReports: number;
  usersProtected: number;
  moneySaved: string;
  threatsBlocked: number;
  scamTypes: Array<{
    name: string;
    count: number;
    percentage: number;
  }>;
  monthlyData: Array<{
    month: string;
    reports: number;
    blocked: number;
  }>;
  topThreats: Array<{
    name: string;
    reports: number;
    severity: string;
    trend: string;
  }>;
}

Deno.serve(async (req: Request) => {
  try {
    if (req.method === "OPTIONS") {
      return new Response(null, {
        status: 200,
        headers: corsHeaders,
      });
    }

    if (req.method === "GET") {
      const stats: Statistics = {
        totalReports: 24567,
        usersProtected: 156789,
        moneySaved: '$2.4M',
        threatsBlocked: 89234,
        scamTypes: [
          { name: 'Phishing', count: 8945, percentage: 36.4 },
          { name: 'Phone Scams', count: 6234, percentage: 25.4 },
          { name: 'Investment Fraud', count: 4567, percentage: 18.6 },
          { name: 'Romance Scams', count: 2890, percentage: 11.8 },
          { name: 'Tech Support', count: 1931, percentage: 7.8 }
        ],
        monthlyData: [
          { month: 'Jan', reports: 1850, blocked: 7200 },
          { month: 'Feb', reports: 2100, blocked: 8100 },
          { month: 'Mar', reports: 1950, blocked: 7800 },
          { month: 'Apr', reports: 2300, blocked: 8900 },
          { month: 'May', reports: 2150, blocked: 8400 },
          { month: 'Jun', reports: 2450, blocked: 9200 }
        ],
        topThreats: [
          { name: 'Fake IRS Emails', reports: 1247, severity: 'High', trend: '+23%' },
          { name: 'Romance Scams', reports: 892, severity: 'Critical', trend: '+15%' },
          { name: 'Tech Support Calls', reports: 634, severity: 'Medium', trend: '-8%' },
          { name: 'Crypto Investment', reports: 423, severity: 'High', trend: '+45%' }
        ]
      };

      return new Response(
        JSON.stringify({
          success: true,
          statistics: stats,
        }),
        {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    return new Response(
      JSON.stringify({ error: "Method not allowed" }),
      {
        status: 405,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});