import React, { useState, useEffect } from 'react';
import LoginPage from './components/LoginPage';
import SignUpPage from './components/SignUpPage';
import Dashboard from './components/Dashboard';
import ReportScamPage from './components/ReportScamPage';
import LearnPage from './components/LearnPage';
import SupportPage from './components/SupportPage';
import PrivacyPage from './components/PrivacyPage';
import TermsPage from './components/TermsPage';
import ContactPage from './components/ContactPage';
import AccountSecurityPage from './components/AccountSecurityPage';
import ScamAlertsPage from './components/ScamAlertsPage';
import StatisticsPage from './components/StatisticsPage';
import { apiService } from './services/api';

type AuthState = 'login' | 'signup' | 'authenticated';
type PageState = 'dashboard' | 'report' | 'learn' | 'support' | 'privacy' | 'terms' | 'contact' | 'account-security' | 'scam-alerts' | 'statistics';

function App() {
  const [authState, setAuthState] = useState<AuthState>('login');
  const [currentPage, setCurrentPage] = useState<PageState>('dashboard');
  const [currentUser, setCurrentUser] = useState<string>('');
  const [isLoading, setIsLoading] = useState(true);

  // Check for existing authentication on app load
  useEffect(() => {
    const checkAuth = () => {
      if (apiService.isAuthenticated()) {
        const userData = apiService.getCurrentUser();
        if (userData) {
          setCurrentUser(userData.username);
          setAuthState('authenticated');
        }
      }
      setIsLoading(false);
    };

    checkAuth();
  }, []);

  const handleLogin = (username: string) => {
    setCurrentUser(username);
    setAuthState('authenticated');
    setCurrentPage('dashboard');
  };

  const handleSignUp = (username: string) => {
    setCurrentUser(username);
    setAuthState('authenticated');
    setCurrentPage('dashboard');
  };

  const handleLogout = async () => {
    try {
      await apiService.logout();
      setCurrentUser('');
      setAuthState('login');
      setCurrentPage('dashboard');
    } catch (error) {
      console.error('Logout error:', error);
      // Force logout even if API call fails
      setCurrentUser('');
      setAuthState('login');
      setCurrentPage('dashboard');
    }
  };

  const handleNavigate = (page: PageState) => {
    setCurrentPage(page);
  };

  // Show loading screen while checking authentication
  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-teal-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-400">Loading...</p>
        </div>
      </div>
    );
  }

  if (authState === 'authenticated') {
    switch (currentPage) {
      case 'report':
        return <ReportScamPage currentUser={currentUser} onLogout={handleLogout} onNavigate={handleNavigate} />;
      case 'learn':
        return <LearnPage currentUser={currentUser} onLogout={handleLogout} onNavigate={handleNavigate} />;
      case 'support':
        return <SupportPage currentUser={currentUser} onLogout={handleLogout} onNavigate={handleNavigate} />;
      case 'privacy':
        return <PrivacyPage currentUser={currentUser} onLogout={handleLogout} onNavigate={handleNavigate} />;
      case 'terms':
        return <TermsPage currentUser={currentUser} onLogout={handleLogout} onNavigate={handleNavigate} />;
      case 'contact':
        return <ContactPage currentUser={currentUser} onLogout={handleLogout} onNavigate={handleNavigate} />;
      case 'account-security':
        return <AccountSecurityPage currentUser={currentUser} onLogout={handleLogout} onNavigate={handleNavigate} />;
      case 'scam-alerts':
        return <ScamAlertsPage currentUser={currentUser} onLogout={handleLogout} onNavigate={handleNavigate} />;
      case 'statistics':
        return <StatisticsPage currentUser={currentUser} onLogout={handleLogout} onNavigate={handleNavigate} />;
      default:
        return <Dashboard currentUser={currentUser} onLogout={handleLogout} onNavigate={handleNavigate} />;
    }
  }

  return (
    <div className="min-h-screen bg-slate-900 relative overflow-hidden">
      {/* Circuit Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <svg className="w-full h-full" viewBox="0 0 1000 1000" fill="none">
          <defs>
            <pattern id="circuit" x="0" y="0" width="100" height="100" patternUnits="userSpaceOnUse">
              <path d="M20 20h60v20h-20v20h-20v-20h-20z" stroke="#14b8a6" strokeWidth="1" fill="none"/>
              <circle cx="30" cy="30" r="2" fill="#14b8a6"/>
              <circle cx="70" cy="50" r="2" fill="#14b8a6"/>
              <path d="M50 10v80M10 50h80" stroke="#14b8a6" strokeWidth="0.5" opacity="0.5"/>
            </pattern>
          </defs>
          <rect width="1000" height="1000" fill="url(#circuit)"/>
        </svg>
      </div>

      {authState === 'login' && (
        <LoginPage 
          onLogin={handleLogin}
          onSwitchToSignUp={() => setAuthState('signup')}
        />
      )}
      
      {authState === 'signup' && (
        <SignUpPage 
          onSignUp={handleSignUp}
          onSwitchToLogin={() => setAuthState('login')}
        />
      )}
    </div>
  );
}

export default App;