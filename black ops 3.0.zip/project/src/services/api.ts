const API_BASE_URL = import.meta.env.VITE_SUPABASE_URL 
  ? `${import.meta.env.VITE_SUPABASE_URL}/functions/v1`
  : 'http://localhost:54321/functions/v1';

const API_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

class ApiService {
  private async makeRequest(endpoint: string, options: RequestInit = {}) {
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${API_KEY}`,
      ...options.headers,
    };

    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        ...options,
        headers,
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || `HTTP error! status: ${response.status}`);
      }

      return data;
    } catch (error) {
      console.error('API request failed:', error);
      throw error;
    }
  }

  // Authentication
  async login(username: string, password: string) {
    if (!username.trim() || !password.trim()) {
      throw new Error('Username and password are required');
    }

    return this.makeRequest('/auth', {
      method: 'POST',
      body: JSON.stringify({
        action: 'login',
        username: username.trim(),
        password,
      }),
    });
  }

  async signup(username: string, password: string, email: string) {
    if (!username.trim() || !password.trim() || !email.trim()) {
      throw new Error('All fields are required');
    }

    if (password.length < 6) {
      throw new Error('Password must be at least 6 characters long');
    }

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      throw new Error('Please enter a valid email address');
    }

    return this.makeRequest('/auth', {
      method: 'POST',
      body: JSON.stringify({
        action: 'signup',
        username: username.trim(),
        password,
        email: email.trim(),
      }),
    });
  }

  async logout() {
    // Clear local storage
    localStorage.removeItem('auth_token');
    localStorage.removeItem('user_data');
    return { success: true };
  }

  // Check if user is authenticated
  isAuthenticated(): boolean {
    const token = localStorage.getItem('auth_token');
    if (!token) return false;

    try {
      const payload = JSON.parse(atob(token));
      return payload.exp > Date.now();
    } catch {
      return false;
    }
  }

  // Get current user data
  getCurrentUser() {
    const userData = localStorage.getItem('user_data');
    return userData ? JSON.parse(userData) : null;
  }

  // Scam Reports
  async submitScamReport(reportData: any) {
    return this.makeRequest('/scam-reports', {
      method: 'POST',
      body: JSON.stringify(reportData),
    });
  }

  async getScamReports(userId?: string) {
    const params = userId ? `?userId=${userId}` : '';
    return this.makeRequest(`/scam-reports${params}`);
  }

  // Scam Alerts
  async getScamAlerts(severity?: string) {
    const params = severity ? `?severity=${severity}` : '';
    return this.makeRequest(`/scam-alerts${params}`);
  }

  // Statistics
  async getStatistics() {
    return this.makeRequest('/statistics');
  }

  // Support
  async submitSupportTicket(ticketData: any) {
    return this.makeRequest('/support', {
      method: 'POST',
      body: JSON.stringify(ticketData),
    });
  }

  async submitContactMessage(messageData: any) {
    return this.makeRequest('/support', {
      method: 'POST',
      body: JSON.stringify(messageData),
    });
  }

  async getSupportTickets(userId?: string) {
    const params = userId ? `?userId=${userId}` : '';
    return this.makeRequest(`/support${params}`);
  }
}

export const apiService = new ApiService();