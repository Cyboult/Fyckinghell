import React from 'react';
import { ArrowLeft, BookOpen, Shield, AlertTriangle, Lock, Eye, Smartphone } from 'lucide-react';
import Header from './shared/Header';

interface LearnPageProps {
  currentUser: string;
  onLogout: () => void;
  onNavigate: (page: string) => void;
}

const LearnPage: React.FC<LearnPageProps> = ({ currentUser, onLogout, onNavigate }) => {
  const articles = [
    {
      title: '10 Ways to Prevent Phishing Attacks',
      description: 'Learn how to identify and avoid phishing emails, texts, and websites that try to steal your personal information.',
      icon: Shield,
      category: 'Email Security',
      readTime: '5 min read',
      difficulty: 'Beginner'
    },
    {
      title: 'Secure Password Best Practices',
      description: 'Create strong, unique passwords and learn about password managers to keep your accounts safe.',
      icon: Lock,
      category: 'Account Security',
      readTime: '7 min read',
      difficulty: 'Beginner'
    },
    {
      title: 'Recognizing Social Engineering Tactics',
      description: 'Understand how scammers manipulate people and learn to recognize common social engineering techniques.',
      icon: Eye,
      category: 'Social Engineering',
      readTime: '8 min read',
      difficulty: 'Intermediate'
    },
    {
      title: 'Mobile Security Essentials',
      description: 'Protect your smartphone and tablet from malware, unauthorized access, and data theft.',
      icon: Smartphone,
      category: 'Mobile Security',
      readTime: '6 min read',
      difficulty: 'Beginner'
    },
    {
      title: 'Investment Scam Red Flags',
      description: 'Learn to identify fraudulent investment opportunities and protect your financial assets.',
      icon: AlertTriangle,
      category: 'Financial Security',
      readTime: '10 min read',
      difficulty: 'Intermediate'
    },
    {
      title: 'Safe Online Shopping Guide',
      description: 'Shop online securely and avoid fake websites, counterfeit products, and payment scams.',
      icon: Shield,
      category: 'Online Shopping',
      readTime: '5 min read',
      difficulty: 'Beginner'
    }
  ];

  const categories = [
    'All Topics',
    'Email Security',
    'Account Security',
    'Social Engineering',
    'Mobile Security',
    'Financial Security',
    'Online Shopping'
  ];

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Beginner':
        return 'text-green-400 bg-green-400/10';
      case 'Intermediate':
        return 'text-yellow-400 bg-yellow-400/10';
      case 'Advanced':
        return 'text-red-400 bg-red-400/10';
      default:
        return 'text-gray-400 bg-gray-400/10';
    }
  };

  return (
    <div className="min-h-screen bg-slate-900">
      <Header currentUser={currentUser} onLogout={onLogout} onNavigate={onNavigate} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <button
            onClick={() => onNavigate('dashboard')}
            className="flex items-center text-gray-400 hover:text-white transition-colors mb-4"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back to Dashboard
          </button>
          
          <div className="flex items-center space-x-4 mb-6">
            <div className="w-12 h-12 bg-teal-500 rounded-xl flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Security Learning Center</h1>
              <p className="text-gray-400">Stay informed and protect yourself from cyber threats</p>
            </div>
          </div>
        </div>

        {/* Categories */}
        <div className="mb-8">
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <button
                key={category}
                className="px-4 py-2 bg-slate-800/50 border border-slate-700 rounded-lg text-gray-300 hover:text-white hover:border-slate-600 transition-all text-sm"
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        {/* Articles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {articles.map((article, index) => (
            <div
              key={index}
              className="bg-slate-800/30 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/50 hover:border-slate-600/50 transition-all duration-200 hover:transform hover:scale-[1.02] cursor-pointer"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-teal-500/20 rounded-xl flex items-center justify-center">
                  <article.icon className="w-6 h-6 text-teal-400" />
                </div>
                <span className={`px-2 py-1 rounded-lg text-xs font-medium ${getDifficultyColor(article.difficulty)}`}>
                  {article.difficulty}
                </span>
              </div>
              
              <h3 className="text-xl font-bold text-white mb-2">
                {article.title}
              </h3>
              
              <p className="text-gray-400 text-sm mb-4 line-clamp-3">
                {article.description}
              </p>
              
              <div className="flex items-center justify-between text-sm">
                <span className="text-teal-400 font-medium">{article.category}</span>
                <span className="text-gray-500">{article.readTime}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Featured Section */}
        <div className="mt-12 bg-gradient-to-r from-teal-500/10 to-blue-500/10 rounded-2xl p-8 border border-teal-500/20">
          <div className="text-center">
            <Shield className="w-16 h-16 text-teal-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-4">Stay Protected</h2>
            <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
              Knowledge is your best defense against cyber threats. Regularly check our learning center 
              for the latest security tips and threat updates.
            </p>
            <button className="px-6 py-3 bg-teal-500 hover:bg-teal-600 text-white rounded-xl font-medium transition-all duration-200 transform hover:scale-[1.02]">
              Subscribe to Updates
            </button>
          </div>
        </div>
      </main>
    </div>
  );
};

export default LearnPage;