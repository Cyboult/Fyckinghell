import React, { useState } from 'react';
import { ArrowLeft, MessageCircle, Phone, Mail, Clock, CheckCircle, AlertCircle } from 'lucide-react';
import Header from './shared/Header';
import { apiService } from '../services/api';
import { useApi } from '../hooks/useApi';

interface SupportPageProps {
  currentUser: string;
  onLogout: () => void;
  onNavigate: (page: string) => void;
}

const SupportPage: React.FC<SupportPageProps> = ({ currentUser, onLogout, onNavigate }) => {
  const [selectedCategory, setSelectedCategory] = useState('');
  const [message, setMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { loading, error, execute } = useApi();

  const supportOptions = [
    {
      title: 'Live Chat',
      description: 'Get instant help from our support team',
      icon: MessageCircle,
      availability: 'Available 24/7',
      color: 'bg-green-500'
    },
    {
      title: 'Phone Support',
      description: 'Speak directly with a security expert',
      icon: Phone,
      availability: 'Mon-Fri 9AM-6PM EST',
      color: 'bg-blue-500'
    },
    {
      title: 'Email Support',
      description: 'Send us a detailed message',
      icon: Mail,
      availability: 'Response within 24 hours',
      color: 'bg-purple-500'
    }
  ];

  const faqItems = [
    {
      question: 'How do I report a scam?',
      answer: 'You can report a scam by clicking the "Report Scam" button on your dashboard and filling out the detailed form with all relevant information.'
    },
    {
      question: 'What happens after I report a scam?',
      answer: 'Our security team reviews all reports within 24 hours. We may contact you for additional information and will share relevant details with appropriate authorities.'
    },
    {
      question: 'How can I protect myself from phishing emails?',
      answer: 'Always verify sender addresses, avoid clicking suspicious links, never provide personal information via email, and use our learning resources to stay informed about latest threats.'
    },
    {
      question: 'Is my personal information secure?',
      answer: 'Yes, we use industry-standard encryption and security measures to protect all user data. We never share personal information without explicit consent.'
    }
  ];

  const categories = [
    'Account Issues',
    'Reporting Problems',
    'Security Questions',
    'Technical Support',
    'Billing & Payments',
    'Other'
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      await execute(async () => {
        return await apiService.submitSupportTicket({
          userId: currentUser,
          category: selectedCategory,
          message,
        });
      });
      
      setIsSubmitted(true);
      setTimeout(() => {
        setIsSubmitted(false);
        setMessage('');
        setSelectedCategory('');
      }, 3000);
    } catch (err) {
      console.error('Failed to submit support ticket:', err);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900">
      <Header currentUser={currentUser} onLogout={onLogout} onNavigate={onNavigate} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <button
            onClick={() => onNavigate('dashboard')}
            className="flex items-center text-gray-400 hover:text-white transition-colors mb-4"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back to Dashboard
          </button>
          
          <div className="flex items-center space-x-4 mb-6">
            <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center">
              <MessageCircle className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Support Center</h1>
              <p className="text-gray-400">Get help when you need it most</p>
            </div>
          </div>
        </div>

        {/* Support Options */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {supportOptions.map((option, index) => (
            <div
              key={index}
              className="bg-slate-800/30 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/50 hover:border-slate-600/50 transition-all duration-200 hover:transform hover:scale-[1.02] cursor-pointer"
            >
              <div className={`w-12 h-12 ${option.color} rounded-xl flex items-center justify-center mb-4`}>
                <option.icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">{option.title}</h3>
              <p className="text-gray-400 text-sm mb-3">{option.description}</p>
              <div className="flex items-center text-sm text-green-400">
                <Clock className="w-4 h-4 mr-1" />
                {option.availability}
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Contact Form */}
          <div className="bg-slate-800/30 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/50">
            <h2 className="text-2xl font-bold text-white mb-6">Send us a Message</h2>
            
            {error && (
              <div className="mb-6 bg-red-500/10 border border-red-500/20 rounded-xl p-4">
                <p className="text-red-400">Error: {error}</p>
              </div>
            )}
            
            {isSubmitted ? (
              <div className="text-center py-8">
                <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">Message Sent!</h3>
                <p className="text-gray-400">We'll get back to you within 24 hours.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Category
                  </label>
                  <select
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-700/50 border border-slate-600 rounded-xl text-white focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500 transition-all"
                    required
                    disabled={loading}
                  >
                    <option value="">Select a category</option>
                    {categories.map((category) => (
                      <option key={category} value={category}>{category}</option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Message
                  </label>
                  <textarea
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Describe your issue or question in detail..."
                    rows={6}
                    className="w-full px-4 py-3 bg-slate-700/50 border border-slate-600 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500 transition-all resize-none"
                    required
                    disabled={loading}
                  />
                </div>
                
                <button
                  type="submit"
                  className={`w-full py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-xl font-medium transition-all duration-200 transform hover:scale-[1.02] ${
                    loading ? 'opacity-50 cursor-not-allowed' : ''
                  }`}
                  disabled={loading}
                >
                  {loading ? 'Sending...' : 'Send Message'}
                </button>
              </form>
            )}
          </div>

          {/* FAQ */}
          <div className="bg-slate-800/30 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/50">
            <h2 className="text-2xl font-bold text-white mb-6">Frequently Asked Questions</h2>
            
            <div className="space-y-4">
              {faqItems.map((item, index) => (
                <div key={index} className="border-b border-slate-700 pb-4 last:border-b-0">
                  <h3 className="text-white font-medium mb-2 flex items-start">
                    <AlertCircle className="w-5 h-5 text-teal-400 mr-2 mt-0.5 flex-shrink-0" />
                    {item.question}
                  </h3>
                  <p className="text-gray-400 text-sm ml-7">{item.answer}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Emergency Contact */}
        <div className="mt-8 bg-red-500/10 border border-red-500/20 rounded-2xl p-6">
          <div className="flex items-center space-x-3 mb-4">
            <AlertCircle className="w-6 h-6 text-red-400" />
            <h3 className="text-xl font-bold text-red-400">Emergency Support</h3>
          </div>
          <p className="text-red-300 mb-4">
            If you're currently being targeted by a scam or have fallen victim to fraud, contact us immediately:
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <button className="px-6 py-3 bg-red-500 hover:bg-red-600 text-white rounded-xl font-medium transition-all duration-200 transform hover:scale-[1.02]">
              Emergency Hotline: 1-800-SCAM-HELP
            </button>
            <button className="px-6 py-3 border border-red-500 text-red-400 rounded-xl hover:bg-red-500/10 transition-all">
              Live Emergency Chat
            </button>
          </div>
        </div>
      </main>
    </div>
  );
};

export default SupportPage;