import React, { useState } from 'react';
import { Megaphone, Shield, AlertTriangle, BarChart3, User, Cuboid as Cube, Menu, FileText, BookOpen } from 'lucide-react';

interface DashboardProps {
  currentUser: string;
  onLogout: () => void;
  onNavigate: (page: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ currentUser, onLogout, onNavigate }) => {
  const [activeTab, setActiveTab] = useState('HOME');

  const menuItems = [
    { name: 'HOME', label: 'HOME', action: () => setActiveTab('HOME') },
    { name: 'Report', label: 'Report', action: () => onNavigate('report') },
    { name: 'Learn', label: 'Learn', action: () => onNavigate('learn') },
    { name: 'Support', label: 'Support', action: () => onNavigate('support') }
  ];

  const features = [
    {
      title: 'Report a Scam',
      description: '',
      icon: Megaphone,
      color: 'bg-teal-500',
      buttonText: 'Report scam',
      buttonColor: 'bg-teal-600 hover:bg-teal-700',
      action: () => onNavigate('report')
    },
    {
      title: 'Account Security',
      description: 'Learn how to protect your account',
      icon: Shield,
      color: 'bg-teal-500',
      buttonText: null,
      buttonColor: '',
      action: () => onNavigate('account-security')
    },
    {
      title: 'Scam Alerts',
      description: 'See the latest scams and threats',
      icon: AlertTriangle,
      color: 'bg-red-500',
      buttonText: null,
      buttonColor: '',
      action: () => onNavigate('scam-alerts')
    },
    {
      title: 'Statistics',
      description: 'View our scam report statistics',
      icon: BarChart3,
      color: 'bg-teal-500',
      buttonText: null,
      buttonColor: '',
      action: () => onNavigate('statistics')
    }
  ];

  const recentActivities = [
    {
      icon: Menu,
      title: 'You reported a scam',
      date: 'June 20, 2023',
      fullDate: 'June 20, 2023'
    },
    {
      icon: BookOpen,
      title: 'New article: 10 Ways to Prevent Phishing',
      date: 'June 19, 2023',
      fullDate: ''
    }
  ];

  return (
    <div className="min-h-screen bg-slate-900">
      {/* Header */}
      <header className="bg-slate-800/50 backdrop-blur-sm border-b border-slate-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-teal-400 to-teal-600 rounded-lg flex items-center justify-center">
                <Cube className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-white">Black Ops</span>
            </div>

            {/* Navigation */}
            <nav className="hidden md:flex space-x-8">
              {menuItems.map((item) => (
                <button
                  key={item.name}
                  onClick={item.action}
                  className={`text-sm font-medium transition-colors ${
                    activeTab === item.name
                      ? 'text-white'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </nav>

            {/* User Menu */}
            <div className="flex items-center space-x-4">
              <button
                onClick={onLogout}
                className="text-gray-400 hover:text-white text-sm font-medium transition-colors"
              >
                Log out
              </button>
              <div className="w-8 h-8 bg-slate-700 rounded-full flex items-center justify-center relative">
                <User className="w-4 h-4 text-gray-400" />
                <div className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-red-500 rounded-full"></div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-white mb-2">
            Welcome back, {currentUser}
          </h1>
        </div>

        {/* Feature Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-slate-800/30 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/50 hover:border-slate-600/50 transition-all duration-200 hover:transform hover:scale-[1.02] cursor-pointer"
              onClick={feature.action}
            >
              <div className="flex flex-col items-center text-center h-full">
                <div className={`w-16 h-16 ${feature.color} rounded-2xl flex items-center justify-center mb-4`}>
                  <feature.icon className="w-8 h-8 text-white" />
                </div>
                
                <h3 className="text-xl font-bold text-white mb-2">
                  {feature.title}
                </h3>
                
                {feature.description && (
                  <p className="text-gray-400 text-sm mb-4 flex-grow">
                    {feature.description}
                  </p>
                )}
                
                {feature.buttonText && (
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      feature.action();
                    }}
                    className={`px-6 py-2 ${feature.buttonColor} text-white rounded-lg font-medium transition-all duration-200 transform hover:scale-[1.05] mt-auto`}
                  >
                    {feature.buttonText}
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Recent Activity */}
        <div className="bg-slate-800/30 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/50">
          <h2 className="text-2xl font-bold text-white mb-6">Recent Activity</h2>
          
          <div className="space-y-4">
            {recentActivities.map((activity, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-4 bg-slate-700/30 rounded-xl border border-slate-600/30 hover:border-slate-500/50 transition-all duration-200"
              >
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-slate-600 rounded-lg flex items-center justify-center">
                    <activity.icon className="w-5 h-5 text-teal-400" />
                  </div>
                  <div>
                    <h3 className="text-white font-medium">{activity.title}</h3>
                    <p className="text-gray-400 text-sm">{activity.date}</p>
                  </div>
                </div>
                {activity.fullDate && (
                  <span className="text-gray-400 text-sm">{activity.fullDate}</span>
                )}
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800/30 border-t border-slate-700 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex justify-center space-x-8">
            <button 
              onClick={() => onNavigate('privacy')}
              className="text-gray-400 hover:text-white text-sm transition-colors"
            >
              Privacy
            </button>
            <button 
              onClick={() => onNavigate('terms')}
              className="text-gray-400 hover:text-white text-sm transition-colors"
            >
              Terms
            </button>
            <button 
              onClick={() => onNavigate('contact')}
              className="text-gray-400 hover:text-white text-sm transition-colors"
            >
              Contact
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Dashboard;