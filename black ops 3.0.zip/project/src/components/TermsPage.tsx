import React from 'react';
import { ArrowLeft, FileText, Scale, AlertTriangle } from 'lucide-react';
import Header from './shared/Header';

interface TermsPageProps {
  currentUser: string;
  onLogout: () => void;
  onNavigate: (page: string) => void;
}

const TermsPage: React.FC<TermsPageProps> = ({ currentUser, onLogout, onNavigate }) => {
  return (
    <div className="min-h-screen bg-slate-900">
      <Header currentUser={currentUser} onLogout={onLogout} onNavigate={onNavigate} />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <button
            onClick={() => onNavigate('dashboard')}
            className="flex items-center text-gray-400 hover:text-white transition-colors mb-4"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back to Dashboard
          </button>
          
          <div className="flex items-center space-x-4 mb-6">
            <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center">
              <FileText className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Terms of Service</h1>
              <p className="text-gray-400">Last updated: December 2024</p>
            </div>
          </div>
        </div>

        <div className="bg-slate-800/30 backdrop-blur-sm rounded-2xl p-8 border border-slate-700/50">
          <div className="prose prose-invert max-w-none">
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-4 flex items-center">
                <Scale className="w-6 h-6 mr-2 text-teal-400" />
                Acceptance of Terms
              </h2>
              <div className="text-gray-300 space-y-4">
                <p>
                  By accessing and using Black Ops Cybersecurity services, you accept and agree to be bound by the terms and provision of this agreement. If you do not agree to abide by the above, please do not use this service.
                </p>
              </div>
            </div>

            <div className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-4">Service Description</h2>
              <div className="text-gray-300 space-y-4">
                <p>
                  Black Ops Cybersecurity provides a platform for:
                </p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Reporting and tracking cybersecurity threats and scams</li>
                  <li>Educational resources about cybersecurity best practices</li>
                  <li>Community-driven threat intelligence sharing</li>
                  <li>Security alerts and notifications</li>
                  <li>Support services for cybersecurity incidents</li>
                </ul>
              </div>
            </div>

            <div className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-4">User Responsibilities</h2>
              <div className="text-gray-300 space-y-4">
                <p>As a user of our platform, you agree to:</p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Provide accurate and truthful information in all reports</li>
                  <li>Use the service only for legitimate cybersecurity purposes</li>
                  <li>Not attempt to compromise the security of our platform</li>
                  <li>Respect the privacy and rights of other users</li>
                  <li>Comply with all applicable laws and regulations</li>
                  <li>Keep your account credentials secure and confidential</li>
                </ul>
              </div>
            </div>

            <div className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-4">Prohibited Activities</h2>
              <div className="text-gray-300 space-y-4">
                <p>You may not use our service to:</p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Submit false or misleading scam reports</li>
                  <li>Harass, threaten, or intimidate other users</li>
                  <li>Distribute malware or malicious content</li>
                  <li>Attempt to gain unauthorized access to our systems</li>
                  <li>Use automated tools to scrape or harvest data</li>
                  <li>Violate any applicable laws or regulations</li>
                </ul>
              </div>
            </div>

            <div className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-4">Intellectual Property</h2>
              <div className="text-gray-300 space-y-4">
                <p>
                  The service and its original content, features, and functionality are and will remain the exclusive property of Black Ops Cybersecurity and its licensors. The service is protected by copyright, trademark, and other laws.
                </p>
              </div>
            </div>

            <div className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-4">Data and Privacy</h2>
              <div className="text-gray-300 space-y-4">
                <p>
                  Your privacy is important to us. Please review our Privacy Policy, which also governs your use of the service, to understand our practices.
                </p>
                <p>
                  By using our service, you consent to the collection and use of information in accordance with our Privacy Policy.
                </p>
              </div>
            </div>

            <div className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-4">Limitation of Liability</h2>
              <div className="text-gray-300 space-y-4">
                <p>
                  In no event shall Black Ops Cybersecurity, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential, or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your use of the service.
                </p>
              </div>
            </div>

            <div className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-4">Service Availability</h2>
              <div className="text-gray-300 space-y-4">
                <p>
                  We strive to maintain high availability of our services, but we do not guarantee uninterrupted access. We may temporarily suspend or restrict access for maintenance, updates, or other operational reasons.
                </p>
              </div>
            </div>

            <div className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-4">Termination</h2>
              <div className="text-gray-300 space-y-4">
                <p>
                  We may terminate or suspend your account and bar access to the service immediately, without prior notice or liability, under our sole discretion, for any reason whatsoever, including without limitation if you breach the Terms.
                </p>
              </div>
            </div>

            <div className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-4">Contact Information</h2>
              <div className="text-gray-300 space-y-4">
                <p>
                  If you have any questions about these Terms of Service, please contact us:
                </p>
                <div className="bg-slate-700/30 rounded-xl p-4">
                  <p><strong>Email:</strong> legal@blackops-security.com</p>
                  <p><strong>Phone:</strong> 1-800-TERMS</p>
                  <p><strong>Address:</strong> 123 Security Blvd, Cyber City, CC 12345</p>
                </div>
              </div>
            </div>

            <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-6">
              <div className="flex items-start space-x-3">
                <AlertTriangle className="w-6 h-6 text-amber-400 mt-0.5" />
                <div>
                  <h3 className="text-amber-400 font-bold mb-2">Changes to Terms</h3>
                  <p className="text-amber-300/80 text-sm">
                    We reserve the right, at our sole discretion, to modify or replace these Terms at any time. 
                    If a revision is material, we will try to provide at least 30 days notice prior to any new 
                    terms taking effect. What constitutes a material change will be determined at our sole discretion.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default TermsPage;