import React, { useState } from 'react';
import { User, Cuboid as Cube } from 'lucide-react';

interface HeaderProps {
  currentUser: string;
  onLogout: () => void;
  onNavigate: (page: string) => void;
}

const Header: React.FC<HeaderProps> = ({ currentUser, onLogout, onNavigate }) => {
  const [activeTab, setActiveTab] = useState('');

  const menuItems = [
    { name: 'HOME', label: 'HOME', action: () => onNavigate('dashboard') },
    { name: 'Report', label: 'Report', action: () => onNavigate('report') },
    { name: 'Learn', label: 'Learn', action: () => onNavigate('learn') },
    { name: 'Support', label: 'Support', action: () => onNavigate('support') }
  ];

  return (
    <header className="bg-slate-800/50 backdrop-blur-sm border-b border-slate-700">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <button
            onClick={() => onNavigate('dashboard')}
            className="flex items-center space-x-3 hover:opacity-80 transition-opacity"
          >
            <div className="w-8 h-8 bg-gradient-to-br from-teal-400 to-teal-600 rounded-lg flex items-center justify-center">
              <Cube className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-white">Black Ops</span>
          </button>

          {/* Navigation */}
          <nav className="hidden md:flex space-x-8">
            {menuItems.map((item) => (
              <button
                key={item.name}
                onClick={() => {
                  setActiveTab(item.name);
                  item.action();
                }}
                className={`text-sm font-medium transition-colors ${
                  activeTab === item.name
                    ? 'text-white'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* User Menu */}
          <div className="flex items-center space-x-4">
            <span className="text-gray-400 text-sm">Welcome, {currentUser}</span>
            <button
              onClick={onLogout}
              className="text-gray-400 hover:text-white text-sm font-medium transition-colors"
            >
              Log out
            </button>
            <div className="w-8 h-8 bg-slate-700 rounded-full flex items-center justify-center relative">
              <User className="w-4 h-4 text-gray-400" />
              <div className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-red-500 rounded-full"></div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;