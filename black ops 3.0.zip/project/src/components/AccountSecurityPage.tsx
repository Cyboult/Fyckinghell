import React, { useState } from 'react';
import { ArrowLeft, Shield, Key, Smartphone, Eye, EyeOff, CheckCircle, AlertTriangle } from 'lucide-react';
import Header from './shared/Header';

interface AccountSecurityPageProps {
  currentUser: string;
  onLogout: () => void;
  onNavigate: (page: string) => void;
}

const AccountSecurityPage: React.FC<AccountSecurityPageProps> = ({ currentUser, onLogout, onNavigate }) => {
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false);
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  const securityFeatures = [
    {
      title: 'Strong Password',
      description: 'Use a unique, complex password for your account',
      icon: Key,
      status: 'enabled',
      color: 'text-green-400'
    },
    {
      title: 'Two-Factor Authentication',
      description: 'Add an extra layer of security to your account',
      icon: Smartphone,
      status: twoFactorEnabled ? 'enabled' : 'disabled',
      color: twoFactorEnabled ? 'text-green-400' : 'text-yellow-400'
    },
    {
      title: 'Login Alerts',
      description: 'Get notified of suspicious login attempts',
      icon: AlertTriangle,
      status: 'enabled',
      color: 'text-green-400'
    }
  ];

  const recentActivity = [
    {
      action: 'Password changed',
      location: 'New York, NY',
      time: '2 hours ago',
      device: 'Chrome on Windows'
    },
    {
      action: 'Login successful',
      location: 'New York, NY',
      time: '1 day ago',
      device: 'Safari on iPhone'
    },
    {
      action: 'Login successful',
      location: 'Boston, MA',
      time: '3 days ago',
      device: 'Firefox on Mac'
    }
  ];

  const handlePasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle password change logic here
    alert('Password updated successfully!');
    setPasswordForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
  };

  const toggleTwoFactor = () => {
    setTwoFactorEnabled(!twoFactorEnabled);
  };

  return (
    <div className="min-h-screen bg-slate-900">
      <Header currentUser={currentUser} onLogout={onLogout} onNavigate={onNavigate} />
      
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <button
            onClick={() => onNavigate('dashboard')}
            className="flex items-center text-gray-400 hover:text-white transition-colors mb-4"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back to Dashboard
          </button>
          
          <div className="flex items-center space-x-4 mb-6">
            <div className="w-12 h-12 bg-teal-500 rounded-xl flex items-center justify-center">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Account Security</h1>
              <p className="text-gray-400">Manage your account security settings</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Security Features */}
          <div className="bg-slate-800/30 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/50">
            <h2 className="text-2xl font-bold text-white mb-6">Security Features</h2>
            
            <div className="space-y-4">
              {securityFeatures.map((feature, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-4 bg-slate-700/30 rounded-xl border border-slate-600/30"
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-slate-600 rounded-lg flex items-center justify-center">
                      <feature.icon className="w-5 h-5 text-teal-400" />
                    </div>
                    <div>
                      <h3 className="text-white font-medium">{feature.title}</h3>
                      <p className="text-gray-400 text-sm">{feature.description}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className={`text-sm font-medium ${feature.color}`}>
                      {feature.status === 'enabled' ? 'Enabled' : 'Disabled'}
                    </span>
                    {feature.title === 'Two-Factor Authentication' && (
                      <button
                        onClick={toggleTwoFactor}
                        className={`px-3 py-1 rounded-lg text-sm font-medium transition-all ${
                          twoFactorEnabled
                            ? 'bg-red-500 hover:bg-red-600 text-white'
                            : 'bg-green-500 hover:bg-green-600 text-white'
                        }`}
                      >
                        {twoFactorEnabled ? 'Disable' : 'Enable'}
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Change Password */}
          <div className="bg-slate-800/30 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/50">
            <h2 className="text-2xl font-bold text-white mb-6">Change Password</h2>
            
            <form onSubmit={handlePasswordChange} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Current Password
                </label>
                <div className="relative">
                  <input
                    type={showCurrentPassword ? 'text' : 'password'}
                    value={passwordForm.currentPassword}
                    onChange={(e) => setPasswordForm({ ...passwordForm, currentPassword: e.target.value })}
                    className="w-full px-4 py-3 bg-slate-700/50 border border-slate-600 rounded-xl text-white focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500 transition-all pr-12"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                    className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white transition-colors"
                  >
                    {showCurrentPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  New Password
                </label>
                <div className="relative">
                  <input
                    type={showNewPassword ? 'text' : 'password'}
                    value={passwordForm.newPassword}
                    onChange={(e) => setPasswordForm({ ...passwordForm, newPassword: e.target.value })}
                    className="w-full px-4 py-3 bg-slate-700/50 border border-slate-600 rounded-xl text-white focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500 transition-all pr-12"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPassword(!showNewPassword)}
                    className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white transition-colors"
                  >
                    {showNewPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Confirm New Password
                </label>
                <input
                  type="password"
                  value={passwordForm.confirmPassword}
                  onChange={(e) => setPasswordForm({ ...passwordForm, confirmPassword: e.target.value })}
                  className="w-full px-4 py-3 bg-slate-700/50 border border-slate-600 rounded-xl text-white focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500 transition-all"
                  required
                />
              </div>
              
              <button
                type="submit"
                className="w-full py-3 bg-teal-500 hover:bg-teal-600 text-white rounded-xl font-medium transition-all duration-200 transform hover:scale-[1.02]"
              >
                Update Password
              </button>
            </form>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="mt-8 bg-slate-800/30 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/50">
          <h2 className="text-2xl font-bold text-white mb-6">Recent Account Activity</h2>
          
          <div className="space-y-4">
            {recentActivity.map((activity, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-4 bg-slate-700/30 rounded-xl border border-slate-600/30"
              >
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-slate-600 rounded-lg flex items-center justify-center">
                    <CheckCircle className="w-5 h-5 text-green-400" />
                  </div>
                  <div>
                    <h3 className="text-white font-medium">{activity.action}</h3>
                    <p className="text-gray-400 text-sm">{activity.device} • {activity.location}</p>
                  </div>
                </div>
                <span className="text-gray-400 text-sm">{activity.time}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Security Tips */}
        <div className="mt-8 bg-teal-500/10 border border-teal-500/20 rounded-2xl p-6">
          <h3 className="text-teal-400 font-bold mb-4 flex items-center">
            <Shield className="w-5 h-5 mr-2" />
            Security Tips
          </h3>
          <ul className="text-teal-300/80 text-sm space-y-2">
            <li>• Use a unique password that's at least 12 characters long</li>
            <li>• Enable two-factor authentication for maximum security</li>
            <li>• Never share your login credentials with anyone</li>
            <li>• Log out from shared or public computers</li>
            <li>• Regularly review your account activity</li>
          </ul>
        </div>
      </main>
    </div>
  );
};

export default AccountSecurityPage;