import React, { useState } from 'react';
import { ArrowLeft, AlertTriangle, TrendingUp, Calendar, MapPin, DollarSign } from 'lucide-react';
import Header from './shared/Header';

interface ScamAlertsPageProps {
  currentUser: string;
  onLogout: () => void;
  onNavigate: (page: string) => void;
}

const ScamAlertsPage: React.FC<ScamAlertsPageProps> = ({ currentUser, onLogout, onNavigate }) => {
  const [selectedSeverity, setSelectedSeverity] = useState('all');

  const alerts = [
    {
      id: 1,
      title: 'Fake IRS Tax Refund Emails',
      description: 'Scammers are sending fake IRS emails claiming you have a tax refund. The emails contain malicious links that steal personal information.',
      severity: 'high',
      type: 'Phishing',
      location: 'Nationwide',
      reportedCases: 1247,
      avgLoss: '$2,340',
      date: '2024-01-15',
      trend: 'increasing'
    },
    {
      id: 2,
      title: 'Romance Scam on Dating Apps',
      description: 'Fraudsters are creating fake profiles on popular dating apps to build relationships and then request money for emergencies.',
      severity: 'critical',
      type: 'Romance Scam',
      location: 'Global',
      reportedCases: 892,
      avgLoss: '$8,750',
      date: '2024-01-14',
      trend: 'stable'
    },
    {
      id: 3,
      title: 'Tech Support Phone Scams',
      description: 'Callers claiming to be from Microsoft or Apple are calling users about computer problems and requesting remote access.',
      severity: 'medium',
      type: 'Phone Scam',
      location: 'North America',
      reportedCases: 634,
      avgLoss: '$450',
      date: '2024-01-13',
      trend: 'decreasing'
    },
    {
      id: 4,
      title: 'Cryptocurrency Investment Fraud',
      description: 'Fake investment platforms promising high returns on cryptocurrency investments are stealing user funds.',
      severity: 'high',
      type: 'Investment Scam',
      location: 'Worldwide',
      reportedCases: 423,
      avgLoss: '$15,200',
      date: '2024-01-12',
      trend: 'increasing'
    },
    {
      id: 5,
      title: 'Package Delivery SMS Scams',
      description: 'Text messages claiming failed package deliveries with malicious links are targeting mobile users.',
      severity: 'medium',
      type: 'SMS Phishing',
      location: 'Europe & US',
      reportedCases: 756,
      avgLoss: '$120',
      date: '2024-01-11',
      trend: 'stable'
    }
  ];

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'bg-red-500 text-white';
      case 'high':
        return 'bg-orange-500 text-white';
      case 'medium':
        return 'bg-yellow-500 text-black';
      case 'low':
        return 'bg-green-500 text-white';
      default:
        return 'bg-gray-500 text-white';
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'increasing':
        return <TrendingUp className="w-4 h-4 text-red-400" />;
      case 'decreasing':
        return <TrendingUp className="w-4 h-4 text-green-400 rotate-180" />;
      default:
        return <div className="w-4 h-4 bg-yellow-400 rounded-full" />;
    }
  };

  const filteredAlerts = selectedSeverity === 'all' 
    ? alerts 
    : alerts.filter(alert => alert.severity === selectedSeverity);

  return (
    <div className="min-h-screen bg-slate-900">
      <Header currentUser={currentUser} onLogout={onLogout} onNavigate={onNavigate} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <button
            onClick={() => onNavigate('dashboard')}
            className="flex items-center text-gray-400 hover:text-white transition-colors mb-4"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back to Dashboard
          </button>
          
          <div className="flex items-center space-x-4 mb-6">
            <div className="w-12 h-12 bg-red-500 rounded-xl flex items-center justify-center">
              <AlertTriangle className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Scam Alerts</h1>
              <p className="text-gray-400">Stay informed about the latest threats and scams</p>
            </div>
          </div>
        </div>

        {/* Filter Buttons */}
        <div className="mb-8">
          <div className="flex flex-wrap gap-2">
            {['all', 'critical', 'high', 'medium', 'low'].map((severity) => (
              <button
                key={severity}
                onClick={() => setSelectedSeverity(severity)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  selectedSeverity === severity
                    ? 'bg-red-500 text-white'
                    : 'bg-slate-800/50 border border-slate-700 text-gray-300 hover:text-white hover:border-slate-600'
                }`}
              >
                {severity.charAt(0).toUpperCase() + severity.slice(1)}
              </button>
            ))}
          </div>
        </div>

        {/* Alerts List */}
        <div className="space-y-6">
          {filteredAlerts.map((alert) => (
            <div
              key={alert.id}
              className="bg-slate-800/30 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/50 hover:border-slate-600/50 transition-all duration-200"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-red-500/20 rounded-xl flex items-center justify-center">
                    <AlertTriangle className="w-6 h-6 text-red-400" />
                  </div>
                  <div>
                    <div className="flex items-center space-x-3 mb-2">
                      <h3 className="text-xl font-bold text-white">{alert.title}</h3>
                      <span className={`px-2 py-1 rounded-lg text-xs font-medium ${getSeverityColor(alert.severity)}`}>
                        {alert.severity.toUpperCase()}
                      </span>
                    </div>
                    <p className="text-gray-400 mb-3">{alert.description}</p>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div className="flex items-center space-x-2">
                        <Calendar className="w-4 h-4 text-gray-500" />
                        <span className="text-gray-300">{new Date(alert.date).toLocaleDateString()}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <MapPin className="w-4 h-4 text-gray-500" />
                        <span className="text-gray-300">{alert.location}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <AlertTriangle className="w-4 h-4 text-gray-500" />
                        <span className="text-gray-300">{alert.reportedCases} reports</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <DollarSign className="w-4 h-4 text-gray-500" />
                        <span className="text-gray-300">Avg loss: {alert.avgLoss}</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  {getTrendIcon(alert.trend)}
                  <span className="text-xs text-gray-400 capitalize">{alert.trend}</span>
                </div>
              </div>
              
              <div className="flex items-center justify-between pt-4 border-t border-slate-700">
                <span className="text-sm text-teal-400 font-medium">{alert.type}</span>
                <button className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg text-sm font-medium transition-all">
                  View Details
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Alert Subscription */}
        <div className="mt-12 bg-gradient-to-r from-red-500/10 to-orange-500/10 rounded-2xl p-8 border border-red-500/20">
          <div className="text-center">
            <AlertTriangle className="w-16 h-16 text-red-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-4">Stay Alert</h2>
            <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
              Subscribe to our alert system to receive immediate notifications about new threats and scams in your area.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="px-6 py-3 bg-red-500 hover:bg-red-600 text-white rounded-xl font-medium transition-all duration-200 transform hover:scale-[1.02]">
                Subscribe to Alerts
              </button>
              <button className="px-6 py-3 border border-red-500 text-red-400 rounded-xl hover:bg-red-500/10 transition-all">
                Customize Preferences
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ScamAlertsPage;