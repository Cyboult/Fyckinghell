import React from 'react';
import { ArrowLeft, Shield, Eye, Lock, Database } from 'lucide-react';
import Header from './shared/Header';

interface PrivacyPageProps {
  currentUser: string;
  onLogout: () => void;
  onNavigate: (page: string) => void;
}

const PrivacyPage: React.FC<PrivacyPageProps> = ({ currentUser, onLogout, onNavigate }) => {
  return (
    <div className="min-h-screen bg-slate-900">
      <Header currentUser={currentUser} onLogout={onLogout} onNavigate={onNavigate} />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <button
            onClick={() => onNavigate('dashboard')}
            className="flex items-center text-gray-400 hover:text-white transition-colors mb-4"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back to Dashboard
          </button>
          
          <div className="flex items-center space-x-4 mb-6">
            <div className="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Privacy Policy</h1>
              <p className="text-gray-400">Last updated: December 2024</p>
            </div>
          </div>
        </div>

        <div className="bg-slate-800/30 backdrop-blur-sm rounded-2xl p-8 border border-slate-700/50">
          <div className="prose prose-invert max-w-none">
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-4 flex items-center">
                <Eye className="w-6 h-6 mr-2 text-teal-400" />
                Information We Collect
              </h2>
              <div className="text-gray-300 space-y-4">
                <p>
                  At Black Ops Cybersecurity, we collect information to provide better services to our users and protect against cyber threats:
                </p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li><strong>Account Information:</strong> Username, email address, and encrypted password</li>
                  <li><strong>Scam Reports:</strong> Details about reported scams, including descriptions and evidence</li>
                  <li><strong>Usage Data:</strong> How you interact with our platform to improve our services</li>
                  <li><strong>Security Logs:</strong> Access logs and security-related activities for protection</li>
                </ul>
              </div>
            </div>

            <div className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-4 flex items-center">
                <Lock className="w-6 h-6 mr-2 text-teal-400" />
                How We Use Your Information
              </h2>
              <div className="text-gray-300 space-y-4">
                <p>We use the collected information for the following purposes:</p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Provide and maintain our cybersecurity services</li>
                  <li>Process and investigate scam reports</li>
                  <li>Send security alerts and educational content</li>
                  <li>Improve our threat detection capabilities</li>
                  <li>Comply with legal obligations and law enforcement requests</li>
                  <li>Protect against fraud and unauthorized access</li>
                </ul>
              </div>
            </div>

            <div className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-4 flex items-center">
                <Database className="w-6 h-6 mr-2 text-teal-400" />
                Data Protection & Security
              </h2>
              <div className="text-gray-300 space-y-4">
                <p>
                  We implement industry-standard security measures to protect your personal information:
                </p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>End-to-end encryption for all sensitive data</li>
                  <li>Regular security audits and penetration testing</li>
                  <li>Multi-factor authentication for account access</li>
                  <li>Secure data centers with 24/7 monitoring</li>
                  <li>Employee background checks and security training</li>
                </ul>
              </div>
            </div>

            <div className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-4">Information Sharing</h2>
              <div className="text-gray-300 space-y-4">
                <p>We may share your information in the following circumstances:</p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li><strong>Law Enforcement:</strong> When required by law or to prevent criminal activity</li>
                  <li><strong>Threat Intelligence:</strong> Anonymized data to improve cybersecurity for all users</li>
                  <li><strong>Service Providers:</strong> Trusted partners who help us operate our platform</li>
                  <li><strong>Legal Compliance:</strong> To comply with applicable laws and regulations</li>
                </ul>
                <p className="font-medium text-teal-400">
                  We never sell your personal information to third parties.
                </p>
              </div>
            </div>

            <div className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-4">Your Rights</h2>
              <div className="text-gray-300 space-y-4">
                <p>You have the following rights regarding your personal information:</p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Access and review your personal data</li>
                  <li>Request corrections to inaccurate information</li>
                  <li>Delete your account and associated data</li>
                  <li>Export your data in a portable format</li>
                  <li>Opt-out of non-essential communications</li>
                </ul>
              </div>
            </div>

            <div className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-4">Data Retention</h2>
              <div className="text-gray-300 space-y-4">
                <p>
                  We retain your information for as long as necessary to provide our services and comply with legal obligations:
                </p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Account data: Until account deletion</li>
                  <li>Scam reports: 7 years for law enforcement purposes</li>
                  <li>Security logs: 2 years for security analysis</li>
                  <li>Usage analytics: 1 year in anonymized form</li>
                </ul>
              </div>
            </div>

            <div className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-4">Contact Us</h2>
              <div className="text-gray-300 space-y-4">
                <p>
                  If you have questions about this Privacy Policy or our data practices, please contact us:
                </p>
                <div className="bg-slate-700/30 rounded-xl p-4">
                  <p><strong>Email:</strong> privacy@blackops-security.com</p>
                  <p><strong>Phone:</strong> 1-800-PRIVACY</p>
                  <p><strong>Address:</strong> 123 Security Blvd, Cyber City, CC 12345</p>
                </div>
              </div>
            </div>

            <div className="bg-teal-500/10 border border-teal-500/20 rounded-xl p-6">
              <h3 className="text-teal-400 font-bold mb-2">Policy Updates</h3>
              <p className="text-teal-300/80 text-sm">
                We may update this Privacy Policy from time to time. We will notify you of any material changes 
                by posting the new policy on this page and updating the "Last updated" date. Your continued use 
                of our services after any changes constitutes acceptance of the updated policy.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default PrivacyPage;