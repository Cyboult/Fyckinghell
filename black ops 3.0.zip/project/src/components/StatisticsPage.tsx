import React from 'react';
import { ArrowLeft, BarChart3, TrendingUp, Users, DollarSign, AlertTriangle, Shield } from 'lucide-react';
import Header from './shared/Header';

interface StatisticsPageProps {
  currentUser: string;
  onLogout: () => void;
  onNavigate: (page: string) => void;
}

const StatisticsPage: React.FC<StatisticsPageProps> = ({ currentUser, onLogout, onNavigate }) => {
  const stats = [
    {
      title: 'Total Reports',
      value: '24,567',
      change: '+12.5%',
      trend: 'up',
      icon: AlertTriangle,
      color: 'text-blue-400'
    },
    {
      title: 'Users Protected',
      value: '156,789',
      change: '+8.3%',
      trend: 'up',
      icon: Users,
      color: 'text-green-400'
    },
    {
      title: 'Money Saved',
      value: '$2.4M',
      change: '+15.7%',
      trend: 'up',
      icon: DollarSign,
      color: 'text-yellow-400'
    },
    {
      title: 'Threats Blocked',
      value: '89,234',
      change: '+22.1%',
      trend: 'up',
      icon: Shield,
      color: 'text-red-400'
    }
  ];

  const scamTypes = [
    { name: 'Phishing', count: 8945, percentage: 36.4 },
    { name: 'Phone Scams', count: 6234, percentage: 25.4 },
    { name: 'Investment Fraud', count: 4567, percentage: 18.6 },
    { name: 'Romance Scams', count: 2890, percentage: 11.8 },
    { name: 'Tech Support', count: 1931, percentage: 7.8 }
  ];

  const monthlyData = [
    { month: 'Jan', reports: 1850, blocked: 7200 },
    { month: 'Feb', reports: 2100, blocked: 8100 },
    { month: 'Mar', reports: 1950, blocked: 7800 },
    { month: 'Apr', reports: 2300, blocked: 8900 },
    { month: 'May', reports: 2150, blocked: 8400 },
    { month: 'Jun', reports: 2450, blocked: 9200 }
  ];

  const topThreats = [
    {
      name: 'Fake IRS Emails',
      reports: 1247,
      severity: 'High',
      trend: '+23%'
    },
    {
      name: 'Romance Scams',
      reports: 892,
      severity: 'Critical',
      trend: '+15%'
    },
    {
      name: 'Tech Support Calls',
      reports: 634,
      severity: 'Medium',
      trend: '-8%'
    },
    {
      name: 'Crypto Investment',
      reports: 423,
      severity: 'High',
      trend: '+45%'
    }
  ];

  return (
    <div className="min-h-screen bg-slate-900">
      <Header currentUser={currentUser} onLogout={onLogout} onNavigate={onNavigate} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <button
            onClick={() => onNavigate('dashboard')}
            className="flex items-center text-gray-400 hover:text-white transition-colors mb-4"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back to Dashboard
          </button>
          
          <div className="flex items-center space-x-4 mb-6">
            <div className="w-12 h-12 bg-teal-500 rounded-xl flex items-center justify-center">
              <BarChart3 className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Statistics</h1>
              <p className="text-gray-400">Cybersecurity insights and threat analytics</p>
            </div>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <div
              key={index}
              className="bg-slate-800/30 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/50"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 bg-slate-700/50 rounded-xl flex items-center justify-center`}>
                  <stat.icon className={`w-6 h-6 ${stat.color}`} />
                </div>
                <div className="flex items-center space-x-1 text-green-400 text-sm">
                  <TrendingUp className="w-4 h-4" />
                  <span>{stat.change}</span>
                </div>
              </div>
              <h3 className="text-2xl font-bold text-white mb-1">{stat.value}</h3>
              <p className="text-gray-400 text-sm">{stat.title}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Scam Types Chart */}
          <div className="bg-slate-800/30 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/50">
            <h2 className="text-2xl font-bold text-white mb-6">Scam Types Distribution</h2>
            <div className="space-y-4">
              {scamTypes.map((type, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-4 h-4 bg-teal-500 rounded-full"></div>
                    <span className="text-white font-medium">{type.name}</span>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="w-32 bg-slate-700 rounded-full h-2">
                      <div 
                        className="bg-teal-500 h-2 rounded-full" 
                        style={{ width: `${type.percentage}%` }}
                      ></div>
                    </div>
                    <span className="text-gray-400 text-sm w-12 text-right">{type.count}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Monthly Trends */}
          <div className="bg-slate-800/30 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/50">
            <h2 className="text-2xl font-bold text-white mb-6">Monthly Trends</h2>
            <div className="space-y-4">
              {monthlyData.map((data, index) => (
                <div key={index} className="flex items-center justify-between">
                  <span className="text-white font-medium w-12">{data.month}</span>
                  <div className="flex-1 mx-4">
                    <div className="flex items-center space-x-2">
                      <div className="flex-1 bg-slate-700 rounded-full h-2">
                        <div 
                          className="bg-blue-500 h-2 rounded-full" 
                          style={{ width: `${(data.reports / 2500) * 100}%` }}
                        ></div>
                      </div>
                      <span className="text-blue-400 text-sm w-16 text-right">{data.reports}</span>
                    </div>
                    <div className="flex items-center space-x-2 mt-1">
                      <div className="flex-1 bg-slate-700 rounded-full h-2">
                        <div 
                          className="bg-green-500 h-2 rounded-full" 
                          style={{ width: `${(data.blocked / 10000) * 100}%` }}
                        ></div>
                      </div>
                      <span className="text-green-400 text-sm w-16 text-right">{data.blocked}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex items-center justify-center space-x-6 mt-6 pt-4 border-t border-slate-700">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                <span className="text-gray-400 text-sm">Reports</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span className="text-gray-400 text-sm">Threats Blocked</span>
              </div>
            </div>
          </div>
        </div>

        {/* Top Threats */}
        <div className="bg-slate-800/30 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/50 mb-8">
          <h2 className="text-2xl font-bold text-white mb-6">Top Threats This Month</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {topThreats.map((threat, index) => (
              <div
                key={index}
                className="bg-slate-700/30 rounded-xl p-4 border border-slate-600/30"
              >
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-white font-medium text-sm">{threat.name}</h3>
                  <span className={`text-xs px-2 py-1 rounded-lg ${
                    threat.severity === 'Critical' ? 'bg-red-500/20 text-red-400' :
                    threat.severity === 'High' ? 'bg-orange-500/20 text-orange-400' :
                    'bg-yellow-500/20 text-yellow-400'
                  }`}>
                    {threat.severity}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-white">{threat.reports}</span>
                  <span className={`text-sm ${
                    threat.trend.startsWith('+') ? 'text-red-400' : 'text-green-400'
                  }`}>
                    {threat.trend}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Impact Summary */}
        <div className="bg-gradient-to-r from-teal-500/10 to-blue-500/10 rounded-2xl p-8 border border-teal-500/20">
          <div className="text-center">
            <Shield className="w-16 h-16 text-teal-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-4">Community Impact</h2>
            <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
              Together, our community has prevented over $2.4 million in losses and protected 156,789 users from cyber threats. 
              Your reports and vigilance make a real difference in keeping everyone safe.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
              <div className="text-center">
                <div className="text-3xl font-bold text-teal-400 mb-1">98.7%</div>
                <div className="text-gray-400 text-sm">Threat Detection Rate</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-400 mb-1">24/7</div>
                <div className="text-gray-400 text-sm">Monitoring Coverage</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-400 mb-1">&lt;2min</div>
                <div className="text-gray-400 text-sm">Average Response Time</div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default StatisticsPage;